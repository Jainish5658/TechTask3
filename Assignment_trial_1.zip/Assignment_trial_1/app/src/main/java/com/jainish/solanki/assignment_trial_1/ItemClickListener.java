package com.jainish.solanki.assignment_trial_1;

import android.view.View;

public interface ItemClickListener {

    void onItemClickListener(View v, int position);
}
