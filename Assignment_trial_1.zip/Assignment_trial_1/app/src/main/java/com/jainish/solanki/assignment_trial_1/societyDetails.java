package com.jainish.solanki.assignment_trial_1;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class societyDetails extends AppCompatActivity {

    TextView mTitleTv; // mSummary
    ImageView mImageTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_society_details);


       ActionBar actionBar = getSupportActionBar();

        mTitleTv = findViewById(R.id.title);
        mImageTv = findViewById(R.id.imageView);
        //mSummary = findViewById(R.id.summary);

        Intent intent = getIntent();

        String mTitle = intent.getStringExtra("iTitle");
      //  String mSummary = intent.getStringExtra("iSummary");

        byte[] mBytes = getIntent().getByteArrayExtra("iImage");


        Bitmap bitmap = BitmapFactory.decodeByteArray(mBytes, 0, mBytes.length);

       actionBar.setTitle(mTitle);

        mTitleTv.setText(mTitle);
        mImageTv.setImageBitmap(bitmap);



    }
}